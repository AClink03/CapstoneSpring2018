#pragma once
#include "Main.h"



Pilot::Pilot()
{
}


Pilot::~Pilot()
{
}
