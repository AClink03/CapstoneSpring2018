#pragma once

class Render
{
private:
	
public:
	TCODColor col;
	int ch;

	Render(TCODColor Col, int CH);
	Render();
	~Render();
	
};