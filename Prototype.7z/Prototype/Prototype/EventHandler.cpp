#pragma once
#include "Main.h"



EventHandler::EventHandler()
{
}


EventHandler::~EventHandler()
{
}

void EventHandler::PlayerUpdate(TCOD_key_t key)
{
	
}

void EventHandler::NPCUpdate()
{
}
